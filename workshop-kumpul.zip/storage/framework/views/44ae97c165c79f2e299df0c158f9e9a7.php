<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Haha</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
    <link  href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" rel="stylesheet">
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
</head>
<body>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Transaction')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">
                <div class="card border-0 shadow-sm rounded">
                    <div class="card-body">
                        <div class="dropdown mb-3">
                        
                        <a href="<?php echo e(route('transaction.history_transaction')); ?>" class="btn btn-md btn-success">History Transaction</a>
                        </div>
                        
                        
                            
                            
                        
                        
                            <div class="col-2">
                                <label class="form-label" for="transaction_number">Nomor Transaksi :</label>
                                <?php if(!isset($transactions)): ?>
                                    <input readonly type="number" class="form-control form-control-sm mb-3" value="1" name="transaction_number" id="transaction_number" disabled>
                                <?php else: ?>
                                    <input readonly type="number" class="form-control form-control-sm mb-3" value="<?php echo e($transactions->id + 1); ?>" name="transaction_number" id="transaction_number" disabled>
                                <?php endif; ?>
                            </div>
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th scope="col">Nama Product</th>
                                        <th scope="col">Kode Product</th>
                                        <th scope="col">Quantity</th>
                                        <th scope="col">Harga Satuan</th>
                                        <th scope="col">Harga Total</th>
                                        <th scope="col" style="width: 8% ; text-align: center;">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $checkouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $checkout): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($checkout->namaproduct); ?></td>
                                            <td><?php echo e($checkout->kodeproduct); ?></td>
                                            <td><?php echo e($checkout->count); ?></td>
                                            <td><?php echo e("Rp " . number_format($checkout->price,2,',','.')); ?></td>
                                            <td><?php echo e("Rp " . number_format($checkout->total_price,2,',','.')); ?></td>
                                            <td class="text-center">
                                                <input name="kodeproduct" type="hidden" value="<?php echo e($checkout->kodeproduct); ?>">
                                                <form action="<?php echo e(route('transaction.update', $checkout->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>
                                                    <input type="hidden" name="kodeproduct" value="<?php echo e($checkout->kodeproduct); ?>">
                                                    <button type="submit" class="btn btn-sm btn-danger">Cancel</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <div class="alert alert-danger">
                                            Data Products belum Tersedia.
                                        </div>
                                    <?php endif; ?>
                                        <tr>
                                            <td colspan="4"></td>
                                            <td><?php echo e("Rp " . number_format($checkouts->sum('total_price'),2,',','.')); ?></td>
                                            <form action="<?php echo e(route('make.transaction')); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="total_price" value="<?php echo e($checkouts->sum('total_price')); ?>">
                                                <input type="hidden" name="checkouts" value="<?php echo e($checkouts); ?>">
                                                
                                                <?php if(isset($transactions)): ?>
                                                <input type="hidden" name="no_transaction" value="<?php echo e($transactions->id + 1); ?>">
                                                <?php else: ?>
                                                <input type="hidden" name="no_transaction" value="1">
                                                <?php endif; ?>
                                                <td class="text-center"><button type="submit" class="btn btn-sm btn-primary">Buat Nota</button></td>
                                            </form>
                                        </tr>
                                </tbody>
                            </table>
                        

                        <div class="card-body">
                        <table class="table table-bordered pt-2" id="tabel-data">
                            <thead>
                                <tr>
                                    <th scope="col">Nama Product</th>
                                    <th scope="col">Kode Product</th>
                                    <th scope="col">Jumlah</th>
                                    <th scope="col">Harga Jual</th>
                                    <th scope="col" style="width: 10%">Quantity</th>
                                    <th scope="col" style="width: 12%">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($product->namaproduct); ?></td>
                                        <td><?php echo e($product->kodeproduct); ?></td>
                                        <td><?php echo e($product->jumlah); ?></td>
                                        <td><?php echo e("Rp " . number_format($product->hargajual,2,',','.')); ?></td>
                                        
                                        <form action="<?php echo e(route('transaction.store')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <td>
                                                <input style="width: 100% ;" type="number" value="0" name="product_count" min="1" max="<?php echo e($product->jumlah); ?>">
                                            </td>
                                            <?php $__errorArgs = ['product_count'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <td class="text-center">
                                                <input type="hidden" name="kodeproduct" value="<?php echo e($product->kodeproduct); ?>">
                                                <?php echo method_field('POST'); ?>
                                                <button type="submit" class="btn btn-sm btn-primary">Tambah</button>
                                            </td>
                                        </form>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="alert alert-danger">
                                        Data Products belum Tersedia.
                                    </div>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        //message with sweetalert
        <?php if(session('success')): ?>
            Swal.fire({
                icon: "success",
                title: "BERHASIL",
                text: "<?php echo e(session('success')); ?>",
                showConfirmButton: false,
                timer: 2000
            });
        <?php elseif(session('error')): ?>
            Swal.fire({
                icon: "error",
                title: "GAGAL!",
                text: "<?php echo e(session('error')); ?>",
                showConfirmButton: false,
                timer: 2000
            });
        <?php endif; ?>
    </script>

<script>
    $(document).ready(function(){
        $('#tabel-data').DataTable();
    });
</script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\workshop\resources\views\transaction\transaction.blade.php ENDPATH**/ ?>