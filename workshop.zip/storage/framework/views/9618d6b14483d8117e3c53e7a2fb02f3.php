<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mt-4">
        <a href="<?php echo e(route('products.index')); ?>" class="btn btn-md btn-danger me-3 mb-4">Back</a>
        <table class="table table-bordered pt-2" id="tabel-data">
            <thead class="table-primary">
                <tr>
                    <th scope="col">User Input</th>
                    <th scope="col">Nama Product</th>
                    <th scope="col">Kode Product</th>
                    <th scope="col">Jumlah</th>
                    <th scope="col">Harga Masuk</th>
                    <th scope="col">Harga Jual</th>
                    <th scope="col">Waktu</th>
                    <th scope="col" style="width: 12%">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        
                        <td><?php echo e($product->user->name); ?></td>
                        <td><?php echo e($product->namaproduct); ?></td>
                        <td><?php echo e($product->kodeproduct); ?></td>
                        <td><?php echo e($product->jumlah); ?></td>
                        <td><?php echo e("Rp " . number_format($product->hargamasuk,2,',','.')); ?></td>
                        <td><?php echo e("Rp " . number_format($product->hargajual,2,',','.')); ?></td>
                        <td><?php echo e($product->created_at); ?></td>
                        <td class="text-center">
                            <?php echo e($product->action); ?>

                            
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="alert alert-danger">
                        Data Products belum Tersedia.
                    </div>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\workshop\resources\views\products\detail_products.blade.php ENDPATH**/ ?>